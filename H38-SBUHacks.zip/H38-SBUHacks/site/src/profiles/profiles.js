import React, { Component } from 'react';
import '../App.css';

class Profile extends Component {
    render() {
      

          
      }
}

export default Profile;